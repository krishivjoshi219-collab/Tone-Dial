import json
import math
import numpy as np
from shapely.geometry import LineString, Polygon
from shapely.ops import orient
import manifold3d
from manifold3d import Manifold, CrossSection, JoinType, OpType
import trimesh

with open('/tmp/exact_cad_features.json') as f:
    feat = json.load(f)

with open('/tmp/extracted_geo.json') as f:
    geo = json.load(f)

def clean_poly(pts):
    p = orient(Polygon(pts), sign=1.0)
    return list(p.exterior.coords)[:-1]

def make_ribbon(pts, width=3.2):
    ls = LineString(pts)
    poly = orient(ls.buffer(width / 2.0, cap_style=1, join_style=1), sign=1.0)
    return CrossSection([list(poly.exterior.coords)[:-1]])

outer_shell_pts = clean_poly(feat['outer_shell'])
cs_shell = CrossSection([outer_shell_pts])

# ------------------------------------------------------------------------------
# 1. SCULPTED TOP FACEPLATE (DRAMATIC PROMINENT 3D DIAL RELIEF)
# ------------------------------------------------------------------------------
# Base deck: 3.0mm solid slab
deck_3d = Manifold.extrude(cs_shell, height=3.0)

# Stepped Outer Rim (+1.8mm: z=3.0 to 4.8)
cs_rim = cs_shell - cs_shell.offset(delta=-3.2, join_type=JoinType.Round)
rim_3d = Manifold.extrude(cs_rim, height=1.8).translate([0, 0, 3.0])

# Central Volcano Screen Bezel: Rises 5.5mm (z=3.0 to 8.5) with conical chamfer
volcano_3d = Manifold.cylinder(height=5.5, radius_low=52.0/2, radius_high=41.0/2, circular_segments=64).translate([0, 0, 3.0])

# Concentric outer moat ridge around volcano (+2.2mm: z=3.0 to 5.2)
moat_cs = CrossSection.circle(radius=64.0/2, circular_segments=64) - CrossSection.circle(radius=58.0/2, circular_segments=64)
moat_3d = Manifold.extrude(moat_cs, height=2.2).translate([0, 0, 3.0])

# Rotary Encoder Collar: Rises 3.8mm (z=3.0 to 6.8)
enc_collar_3d = Manifold.cylinder(height=3.8, radius_low=21.0/2, radius_high=20.0/2, circular_segments=48).translate([55.47, 14.37, 3.0])

# 4 Key Bezels: Rises 2.2mm (z=3.0 to 5.2)
key_frames_cs = CrossSection()
for k in ['key1_frame', 'key2_frame', 'key3_frame', 'key4_frame']:
    key_frames_cs = key_frames_cs + CrossSection([clean_poly(feat[k])])
key_frames_3d = Manifold.extrude(key_frames_cs, height=2.2).translate([0, 0, 3.0])

# Fader Frame: Rises 2.2mm (z=3.0 to 5.2)
fader_frame_3d = Manifold.extrude(CrossSection([clean_poly(feat['fader_frame'])]), height=2.2).translate([0, 0, 3.0])

# Swirling Conch Dial Spirals & Ribbons: Prominent raised 3D ridges (+2.2mm: z=3.0 to 5.2)
rib1_3d = Manifold.extrude(make_ribbon(feat['spiral_ribbon1'], width=3.5), height=2.2).translate([0, 0, 3.0])
rib2_3d = Manifold.extrude(make_ribbon(feat['spiral_ribbon2'], width=3.5), height=2.2).translate([0, 0, 3.0])
crest_3d = Manifold.extrude(make_ribbon(feat['spiral_crest'], width=3.2), height=2.0).translate([0, 0, 3.0])
cresc_3d = Manifold.extrude(make_ribbon(feat['crescent'], width=3.8), height=2.4).translate([0, 0, 3.0])
arc1_3d = Manifold.extrude(make_ribbon(feat['screen_lower_arc1'], width=3.0), height=1.8).translate([0, 0, 3.0])
arc2_3d = Manifold.extrude(make_ribbon(feat['screen_lower_arc2'], width=3.0), height=1.8).translate([0, 0, 3.0])

raised_faceplate = (
    deck_3d + rim_3d + volcano_3d + moat_3d + enc_collar_3d + 
    key_frames_3d + fader_frame_3d + rib1_3d + rib2_3d + 
    crest_3d + cresc_3d + arc1_3d + arc2_3d
)

# Recess the Speaker Acoustic Dish (-1.6mm: z=1.4 to 3.1)
spk_dish = Manifold.extrude(CrossSection([clean_poly(feat['speaker_chamber_outer'])]), height=1.7).translate([0, 0, 1.4])
sculpted_faceplate = raised_faceplate - spk_dish

# Through Cutouts
screen_cutter = Manifold.cylinder(height=15.0, radius_low=36.5/2, radius_high=36.5/2, circular_segments=64).translate([0, 0, -2.0])
enc_cutter = Manifold.cylinder(height=15.0, radius_low=7.5/2, radius_high=7.5/2, circular_segments=32).translate([55.47, 14.37, -2.0])

rad = math.radians(-110.0)
c, s = math.cos(rad), math.sin(rad)
tof_corners = np.array([[-4.0, -2.5], [4.0, -2.5], [4.0, 2.5], [-4.0, 2.5]])
tof_rot = np.column_stack([tof_corners[:,0]*c - tof_corners[:,1]*s + 30.0, tof_corners[:,0]*s + tof_corners[:,1]*c - 4.5])
tof_cutter = Manifold.extrude(CrossSection([tof_rot.tolist()]), height=15.0).translate([0, 0, -2.0])

keys_cut_cs = CrossSection()
for k in ['key1_slot', 'key2_slot', 'key3_slot', 'key4_slot']:
    keys_cut_cs = keys_cut_cs + CrossSection([clean_poly(feat[k])])
keys_cutter = Manifold.extrude(keys_cut_cs, height=15.0).translate([0, 0, -2.0])

fader_cutter = Manifold.extrude(CrossSection([clean_poly(feat['fader_slot'])]), height=15.0).translate([0, 0, -2.0])

screws_cs = CrossSection()
corner_screw_coords = [(-48.44, 45.86), (60.66, 46.13), (-49.73, -47.31), (70.85, -52.94)]
for sx, sy in corner_screw_coords:
    screws_cs = screws_cs + CrossSection.circle(radius=3.2/2, circular_segments=24).translate([sx, sy])
screws_cutter = Manifold.extrude(screws_cs, height=15.0).translate([0, 0, -2.0])

spk_circles = [CrossSection.circle(radius=hd/2.0, circular_segments=16).translate([hx, hy]) for hx, hy, hd in geo['speaker_holes']]
spk_cs = CrossSection.batch_boolean(spk_circles, OpType.Add)
spk_cutter = Manifold.extrude(spk_cs, height=15.0).translate([0, 0, -2.0])

top_solid = (
    sculpted_faceplate - screen_cutter - enc_cutter - 
    tof_cutter - keys_cutter - fader_cutter - 
    screws_cutter - spk_cutter
)

m_top = top_solid.to_mesh()
tm_top = trimesh.Trimesh(vertices=m_top.vert_properties[:, :3], faces=m_top.tri_verts, process=True)
tm_top.export('/tmp/test_top_sculpted.stl')
print(f"Top faceplate compiled: Watertight={tm_top.is_watertight}, Vol={tm_top.volume:.1f}, Bounds={tm_top.bounds}")

# ------------------------------------------------------------------------------
# 2. 12-DEGREE ERGONOMIC DESKTOP WEDGE BASE TRAY
# ------------------------------------------------------------------------------
# Base sits flat at z=0. Extrude up to 45mm, then cut with plane at 12 degrees.
# Front (y = -68mm) is at z = 9.0mm
# Center (y = 0mm) is at z = 9.0 + 68*tan(12 deg) = 23.45mm
# Rear (y = +68mm) is at z = 9.0 + 136*tan(12 deg) = 37.90mm
theta = 12.0
rad_th = math.radians(theta)
tan_th = math.tan(rad_th)

# Solid outer wedge
outer_ext = Manifold.extrude(cs_shell, height=45.0)

# Cut off everything above the 12 deg plane
top_cut_box = Manifold.cube([300.0, 300.0, 100.0], center=True).translate([0, 0, 50.0])
rot_cutter = top_cut_box.rotate([-theta, 0, 0]).translate([0, 0, 23.45])
outer_wedge = outer_ext - rot_cutter

# Hollow out cavity with 2.2mm walls and 2.5mm floor
cs_cavity = cs_shell.offset(delta=-2.4, join_type=JoinType.Round)
cavity_ext = Manifold.extrude(cs_cavity, height=45.0).translate([0, 0, 2.5])
# Cut cavity top with 12 deg plane offset down by 0.5mm
cavity_top_cutter = top_cut_box.rotate([-theta, 0, 0]).translate([0, 0, 22.95])
cavity_solid = cavity_ext - cavity_top_cutter

tray_raw = outer_wedge - cavity_solid

# 4 PCB Standoffs (seated on floor, top surfaces at z = 5.5mm)
pcb_standoffs = [(-38.0, 35.0), (38.0, 35.0), (-38.0, -35.0), (38.0, -35.0)]
standoff_posts = Manifold()
standoff_holes = Manifold()
for px, py in pcb_standoffs:
    post = Manifold.cylinder(height=3.0, radius_low=5.5/2, radius_high=5.5/2, circular_segments=24).translate([px, py, 2.5])
    hole = Manifold.cylinder(height=4.0, radius_low=2.5/2, radius_high=2.5/2, circular_segments=24).translate([px, py, 2.0])
    standoff_posts = standoff_posts + post
    standoff_holes = standoff_holes + hole

# USB-C port cutout on front wall: centered at x=0, y=-67.5, z=3.0 to 8.0 (12mm x 5mm)
usbc_cutter = Manifold.cube([12.0, 10.0, 5.0], center=True).translate([0.0, -67.5, 5.5])
pwr_cutter = Manifold.cube([8.5, 10.0, 4.0], center=True).translate([18.0, -66.5, 5.5])

base_tray_wedge = (tray_raw + standoff_posts) - standoff_holes - usbc_cutter - pwr_cutter
m_tray = base_tray_wedge.to_mesh()
tm_tray = trimesh.Trimesh(vertices=m_tray.vert_properties[:, :3], faces=m_tray.tri_verts, process=True)
tm_tray.export('/tmp/test_tray_wedge.stl')
print(f"Base tray compiled: Watertight={tm_tray.is_watertight}, Vol={tm_tray.volume:.1f}, Bounds={tm_tray.bounds}")
