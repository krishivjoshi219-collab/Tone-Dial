import json
import math
import os
import time
import ezdxf
import numpy as np
from shapely.geometry import LineString, Polygon
from shapely.ops import orient
import manifold3d
from manifold3d import Manifold, CrossSection, JoinType, OpType
import trimesh

t_start = time.time()
print("=" * 80)
print("BUILDING TRUE 3D CONCH DOME TONE DIAL ENCLOSURE (100% HOLLOW TRAY)")
print("=" * 80)

with open('/tmp/exact_cad_features.json') as f:
    feat = json.load(f)

with open('/tmp/extracted_geo.json') as f:
    geo = json.load(f)

def clean_poly(pts):
    p = orient(Polygon(pts), sign=1.0)
    return list(p.exterior.coords)[:-1]

def make_ribbon(pts, width=3.2):
    ls = LineString(pts)
    poly = orient(ls.buffer(width / 2.0, cap_style=1, join_style=1), sign=1.0)
    return CrossSection([list(poly.exterior.coords)[:-1]])

outer_shell_pts = clean_poly(feat['outer_shell'])
cs_shell = CrossSection([outer_shell_pts])
corner_screw_coords = [(-48.44, 45.86), (60.66, 46.13), (-49.73, -47.31), (70.85, -52.94)]

# ------------------------------------------------------------------------------
# 1. BUILD TRUE 3D DOMED CONCH DIAL FACEPLATE
# ------------------------------------------------------------------------------
print("1. Sculpting True 3D Domed Conch Dial Faceplate...")

R = 550.0
z_c = -542.0
sphere = Manifold.sphere(radius=R, circular_segments=128).translate([0, 0, z_c])
deck_ext = Manifold.extrude(cs_shell, height=15.0)
domed_deck = deck_ext ^ sphere

# Hollow inside leaving 2.5mm floor/wall thickness
cs_cavity = cs_shell.offset(delta=-2.4, join_type=JoinType.Round)
cavity_ext = Manifold.extrude(cs_cavity, height=15.0).translate([0, 0, -0.5])
sphere_inner = Manifold.sphere(radius=R, circular_segments=128).translate([0, 0, z_c - 2.5])
cavity_domed = cavity_ext ^ sphere_inner
domed_shell = domed_deck - cavity_domed

# Central Volcano Screen Bezel
cone = Manifold.cylinder(height=5.0, radius_low=50.0/2, radius_high=41.0/2, circular_segments=64).translate([0, 0, 7.0])

# Outer Moat Ring
moat_cs = CrossSection.circle(radius=64.0/2, circular_segments=64) - CrossSection.circle(radius=57.0/2, circular_segments=64)
moat = Manifold.extrude(moat_cs, height=4.0).translate([0, 0, 5.0])

# Rotary Encoder Collar at (55.47, 14.37)
enc_collar = Manifold.cylinder(height=4.0, radius_low=21.0/2, radius_high=20.0/2, circular_segments=48).translate([55.47, 14.37, 4.0])

# 4 Key Bezels
key_frames_cs = CrossSection()
for k in ['key1_frame', 'key2_frame', 'key3_frame', 'key4_frame']:
    key_frames_cs = key_frames_cs + CrossSection([clean_poly(feat[k])])
key_frames = Manifold.extrude(key_frames_cs, height=4.0).translate([0, 0, 2.5])

# Fader Bezel Frame
fader_frame = Manifold.extrude(CrossSection([clean_poly(feat['fader_frame'])]), height=4.0).translate([0, 0, 2.5])

# Conch Spiral Ribbons & Crest
rib1 = Manifold.extrude(make_ribbon(feat['spiral_ribbon1'], width=3.5), height=4.0).translate([0, 0, 4.0])
rib2 = Manifold.extrude(make_ribbon(feat['spiral_ribbon2'], width=3.5), height=4.0).translate([0, 0, 4.0])
crest = Manifold.extrude(make_ribbon(feat['spiral_crest'], width=3.2), height=4.0).translate([0, 0, 4.0])
cresc = Manifold.extrude(make_ribbon(feat['crescent'], width=3.8), height=4.0).translate([0, 0, 3.5])

domed_all = domed_shell + cone + moat + enc_collar + key_frames + fader_frame + rib1 + rib2 + crest + cresc

# Recess the Speaker Acoustic Dish (-1.8mm)
spk_dish = Manifold.extrude(CrossSection([clean_poly(feat['speaker_chamber_outer'])]), height=2.0).translate([0, 0, 2.5])
sculpted = domed_all - spk_dish

# Cutouts:
screen_cut = Manifold.cylinder(height=20.0, radius_low=36.5/2, radius_high=36.5/2, circular_segments=64).translate([0, 0, -5.0])
enc_cut = Manifold.cylinder(height=20.0, radius_low=7.5/2, radius_high=7.5/2, circular_segments=32).translate([55.47, 14.37, -5.0])

keys_cut_cs = CrossSection()
for k in ['key1_slot', 'key2_slot', 'key3_slot', 'key4_slot']:
    keys_cut_cs = keys_cut_cs + CrossSection([clean_poly(feat[k])])
keys_cut = Manifold.extrude(keys_cut_cs, height=20.0).translate([0, 0, -5.0])

fader_cut = Manifold.extrude(CrossSection([clean_poly(feat['fader_slot'])]), height=20.0).translate([0, 0, -5.0])

rad = math.radians(-110.0)
c, s = math.cos(rad), math.sin(rad)
tof_corners = np.array([[-4.0, -2.5], [4.0, -2.5], [4.0, 2.5], [-4.0, 2.5]])
tof_rot = np.column_stack([tof_corners[:,0]*c - tof_corners[:,1]*s + 30.0, tof_corners[:,0]*s + tof_corners[:,1]*c - 4.5])
tof_cut = Manifold.extrude(CrossSection([tof_rot.tolist()]), height=20.0).translate([0, 0, -5.0])

screws_cs = CrossSection()
for sx, sy in corner_screw_coords:
    screws_cs = screws_cs + CrossSection.circle(radius=3.2/2, circular_segments=24).translate([sx, sy])
screws_cut = Manifold.extrude(screws_cs, height=20.0).translate([0, 0, -5.0])

spk_circles = [CrossSection.circle(radius=hd/2.0, circular_segments=16).translate([hx, hy]) for hx, hy, hd in geo['speaker_holes']]
spk_cs = CrossSection.batch_boolean(spk_circles, OpType.Add)
spk_cut = Manifold.extrude(spk_cs, height=20.0).translate([0, 0, -5.0])

faceplate_final = sculpted - screen_cut - enc_cut - keys_cut - fader_cut - tof_cut - screws_cut - spk_cut

m_top = faceplate_final.to_mesh()
tm_top = trimesh.Trimesh(vertices=m_top.vert_properties[:, :3], faces=m_top.tri_verts, process=True)
tm_top.visual.vertex_colors = [35, 175, 205, 255]
tm_top.export('Top_Faceplate.stl')
print(f"   ✓ Top_Faceplate.stl | Watertight: {tm_top.is_watertight} | Vol: {tm_top.volume:.1f} mm³ | Bounds: {tm_top.bounds}")

# ------------------------------------------------------------------------------
# 2. BUILD OPENABLE BASE TRAY (100% HOLLOW WEDGE CAVITY FOR PCB & BATTERY)
# ------------------------------------------------------------------------------
print("2. Building 100% Open Hollow 12° Desktop Wedge Base Tray...")

theta = 12.0
rad_th = math.radians(theta)
tan_th = math.tan(rad_th)

# Solid outer wedge: Extrude to 45mm, cut with plane at 12 deg
outer_ext = Manifold.extrude(cs_shell, height=45.0)
top_cut_box = Manifold.cube([300.0, 300.0, 100.0], center=True).translate([0, 0, 50.0])
rot_cutter = top_cut_box.rotate([-theta, 0, 0]).translate([0, 0, 23.45])
outer_wedge = outer_ext - rot_cutter

# PURE HOLLOW CAVITY:
# Starts at z=2.5mm (2.5mm floor thickness) and extends to z=55mm (PUNCHING COMPLETELY THROUGH TOP RIM)
# Wall thickness: 2.4mm
cs_cavity = cs_shell.offset(delta=-2.4, join_type=JoinType.Round)
cavity_cutter = Manifold.extrude(cs_cavity, height=55.0).translate([0, 0, 2.5])

# Subtracting cavity_cutter creates a 100% OPEN TUB with zero top ceiling!
tray_open_tub = outer_wedge - cavity_cutter

# 4 PCB Standoffs: Bosses rising 3.5mm from floor (z=2.5 to 6.0mm) inside the hollow tub
# Perfectly sized for the 96x95mm KiCAD PCB
pcb_standoffs = [(-38.0, 35.0), (38.0, 35.0), (-38.0, -35.0), (38.0, -35.0)]
standoff_posts = Manifold()
standoff_holes = Manifold()
for px, py in pcb_standoffs:
    post = Manifold.cylinder(height=3.5, radius_low=6.0/2, radius_high=6.0/2, circular_segments=24).translate([px, py, 2.5])
    hole = Manifold.cylinder(height=4.5, radius_low=2.5/2, radius_high=2.5/2, circular_segments=24).translate([px, py, 2.0])
    standoff_posts = standoff_posts + post
    standoff_holes = standoff_holes + hole

# 4 Corner Screw Boss Posts inside the 4 ears (extending up near the rim with M3 pilot holes)
corner_screw_posts = Manifold()
corner_screw_holes = Manifold()
for sx, sy in corner_screw_coords:
    # Top rim height at this ear position: z_rim(sy) = 23.45 - sy * tan(12 deg)
    z_rim_ear = 23.45 - sy * tan_th
    boss_h = z_rim_ear - 3.0
    boss = Manifold.cylinder(height=boss_h, radius_low=7.0/2, radius_high=7.0/2, circular_segments=24).translate([sx, sy, 2.5])
    shole = Manifold.cylinder(height=boss_h + 2.0, radius_low=3.0/2, radius_high=3.0/2, circular_segments=24).translate([sx, sy, 2.0])
    corner_screw_posts = corner_screw_posts + boss
    corner_screw_holes = corner_screw_holes + shole

# Port Cutouts on Front Wall:
# USB-C port cutout: 12.0 x 5.0mm centered at x=0, y=-67.5, z=3.0 to 8.0
usbc_cutter = Manifold.cube([12.0, 10.0, 5.0], center=True).translate([0.0, -67.5, 5.5])
# Power switch cutout: 8.5 x 4.0mm at x=18.0, y=-66.5, z=3.5 to 7.5
pwr_cutter = Manifold.cube([8.5, 10.0, 4.0], center=True).translate([18.0, -66.5, 5.5])

base_tray_wedge = (
    (tray_open_tub + standoff_posts + corner_screw_posts) - 
    standoff_holes - corner_screw_holes - usbc_cutter - pwr_cutter
)

m_tray = base_tray_wedge.to_mesh()
tm_tray = trimesh.Trimesh(vertices=m_tray.vert_properties[:, :3], faces=m_tray.tri_verts, process=True)
tm_tray.visual.vertex_colors = [55, 60, 70, 255]
tm_tray.export('Base_Tray.stl')
print(f"   ✓ Base_Tray.stl | Watertight: {tm_tray.is_watertight} | Vol: {tm_tray.volume:.1f} mm³ | Bounds: {tm_tray.bounds}")

# ------------------------------------------------------------------------------
# 3. BUILD ROTARY DIAL KNOB
# ------------------------------------------------------------------------------
print("3. Building Rotary Dial Knob (Knurled, Pointer Index, EC11 D-Shaft Bore)...")

r_knob = 15.0 / 2.0
h_knob = 12.0
knob_cyl = Manifold.cylinder(height=h_knob, radius_low=r_knob, radius_high=r_knob - 0.4, circular_segments=48)

flutes = Manifold()
for i in range(24):
    ang = 2.0 * math.pi * i / 24.0
    fx = (r_knob - 0.2) * math.cos(ang)
    fy = (r_knob - 0.2) * math.sin(ang)
    flute = Manifold.cylinder(height=h_knob - 1.0, radius_low=0.5, radius_high=0.5, circular_segments=12).translate([fx, fy, 0.5])
    flutes = flutes + flute
knob_fluted = knob_cyl + flutes

pointer_cs = CrossSection([[[-0.7, 0.0], [0.7, 0.0], [0.5, r_knob - 0.8], [-0.5, r_knob - 0.8]]])
pointer_3d = Manifold.extrude(pointer_cs, height=0.7).translate([0, 0, h_knob - 0.1])
knob_with_pointer = knob_fluted + pointer_3d

shaft_cyl = CrossSection.circle(radius=6.1 / 2.0, circular_segments=32)
d_flat = CrossSection([[[-4.0, 1.5], [4.0, 1.5], [4.0, 4.0], [-4.0, 4.0]]])
shaft_d_cs = shaft_cyl - d_flat
shaft_bore = Manifold.extrude(shaft_d_cs, height=8.0).translate([0, 0, -0.5])
knob_solid = knob_with_pointer - shaft_bore

m_knob = knob_solid.to_mesh()
tm_knob = trimesh.Trimesh(vertices=m_knob.vert_properties[:, :3], faces=m_knob.tri_verts, process=True)
tm_knob.visual.vertex_colors = [225, 185, 50, 255]
tm_knob.export('Tone_Dial_Knob.stl')
print(f"   ✓ Tone_Dial_Knob.stl | Watertight: {tm_knob.is_watertight} | Vol: {tm_knob.volume:.1f} mm³")

# ------------------------------------------------------------------------------
# 4. ASSEMBLED COMPLETE ENCLOSURE (12° TILTED DESKTOP WEDGE CONFIGURATION)
# ------------------------------------------------------------------------------
print("4. Compiling Complete Single-File Assemblies (STL & GLB)...")

Rx_wedge = np.array([
    [1, 0, 0],
    [0, np.cos(-rad_th), -np.sin(-rad_th)],
    [0, np.sin(-rad_th), np.cos(-rad_th)]
])

top_assembled = tm_top.copy()
top_assembled.vertices = (Rx_wedge @ top_assembled.vertices.T).T
top_assembled.apply_translation([0.0, 0.0, 23.45])

knob_assembled = tm_knob.copy()
knob_assembled.apply_translation([55.47, 14.37, 6.0])
knob_assembled.vertices = (Rx_wedge @ knob_assembled.vertices.T).T
knob_assembled.apply_translation([0.0, 0.0, 23.45])

complete_assembled = trimesh.util.concatenate([tm_tray, top_assembled, knob_assembled])
complete_assembled.export('Tone_Dial_Complete_Enclosure.stl')
print(f"   ✓ Tone_Dial_Complete_Enclosure.stl | Watertight: {complete_assembled.is_watertight}")

# Exploded View: Lift along tilted normal vector!
normal_lift = np.array([0.0, -np.sin(rad_th), np.cos(rad_th)]) * 50.0
top_exploded = top_assembled.copy()
top_exploded.apply_translation(normal_lift)

knob_exploded = knob_assembled.copy()
knob_exploded.apply_translation(normal_lift * 1.8)

complete_exploded = trimesh.util.concatenate([tm_tray, top_exploded, knob_exploded])
complete_exploded.export('Tone_Dial_Complete_Enclosure_Exploded.stl')
print(f"   ✓ Tone_Dial_Complete_Enclosure_Exploded.stl | Watertight: {complete_exploded.is_watertight}")

# Multi-Body glTF Binary
scene = trimesh.Scene()
scene.add_geometry(tm_tray, node_name="Base_Tray_Wedge")
scene.add_geometry(top_assembled, node_name="Domed_Conch_Faceplate")
scene.add_geometry(knob_assembled, node_name="Rotary_Dial_Knob")
scene.export('Tone_Dial_Complete_Enclosure.glb')
print(f"   ✓ Tone_Dial_Complete_Enclosure.glb (Multi-body Color glTF)")

# ------------------------------------------------------------------------------
# 5. 2D CAD DXF FOR ONSHAPE
# ------------------------------------------------------------------------------
print("5. Generating Mathematical 2D CAD DXF for Onshape...")

doc = ezdxf.new("R2010")
msp = doc.modelspace()

doc.layers.new("SHELL", dxfattribs={"color": 1})
doc.layers.new("ACCENTS", dxfattribs={"color": 4})
doc.layers.new("CUTOUTS", dxfattribs={"color": 3})
doc.layers.new("SPEAKER_GRILL", dxfattribs={"color": 2})
doc.layers.new("SCREWS", dxfattribs={"color": 6})

msp.add_lwpolyline(outer_shell_pts, format="xy", close=True, dxfattribs={"layer": "SHELL"})
msp.add_lwpolyline(feat['outer_rim'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['volcano_outer'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['speaker_chamber_outer'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['crescent'], format="xy", close=False, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['spiral_ribbon1'], format="xy", close=False, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['spiral_ribbon2'], format="xy", close=False, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['spiral_crest'], format="xy", close=False, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['key1_frame'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['key2_frame'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['key3_frame'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['key4_frame'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['fader_frame'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})
msp.add_lwpolyline(feat['encoder_collar'], format="xy", close=True, dxfattribs={"layer": "ACCENTS"})

msp.add_circle(center=(0.0, 0.0), radius=36.5/2.0, dxfattribs={"layer": "CUTOUTS"})
msp.add_circle(center=(55.47, 14.37), radius=7.5/2.0, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(feat['key1_slot'], format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(feat['key2_slot'], format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(feat['key3_slot'], format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(feat['key4_slot'], format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(feat['fader_slot'], format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})
msp.add_lwpolyline(tof_rot.tolist(), format="xy", close=True, dxfattribs={"layer": "CUTOUTS"})

for sx, sy in corner_screw_coords:
    msp.add_circle(center=(sx, sy), radius=3.2/2.0, dxfattribs={"layer": "SCREWS"})

for hx, hy, hd in geo['speaker_holes']:
    msp.add_circle(center=(hx, hy), radius=hd/2.0, dxfattribs={"layer": "SPEAKER_GRILL"})

doc.saveas('Tone_Dial_Pristine.dxf')
doc.saveas('Tone_Dial_Complete.dxf')
print("   ✓ Tone_Dial_Pristine.dxf (Mathematical CAD vectors for Onshape)")

print(f"\nAll operations finished cleanly in {time.time() - t_start:.2f} seconds!")
