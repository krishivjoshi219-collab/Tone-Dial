// ==============================================================================
// Tone Dial Enclosure OpenSCAD Script
// ==============================================================================
// Can be rendered in OpenSCAD GUI or via command line:
//   openscad -o Top_Faceplate.stl -D 'top_faceplate();' tone_dial.scad
//   openscad -o Base_Tray.stl -D 'base_tray();' tone_dial.scad

// 1. TOP FACEPLATE (2.5mm thick with all component cutouts + volcano screen bezel)
module top_faceplate() {
    linear_extrude(height = 2.5) {
        import("Tone_Dial_Pristine.dxf");
    }
    // Raised volcano screen bezel (44mm outer base, 41mm outer top, 36.5mm inner, 2mm tall)
    translate([0, 0, 2.5])
        difference() {
            cylinder(h = 2.0, d1 = 44.0, d2 = 41.0, $fn = 80);
            cylinder(h = 2.1, d = 36.5, $fn = 80);
        }
}

// 2. BOTTOM BASE TRAY (14mm tub, 2mm wall thickness, 2mm floor)
module base_tray() {
    difference() {
        // Outer solid block (14mm height)
        linear_extrude(height = 14.0) {
            import("Tone_Dial_Pristine.dxf", layer = "SHELL");
        }
        // Hollow interior pocket (leaves 2mm floor & 2mm walls)
        translate([0, 0, 2.0])
            linear_extrude(height = 13.0) {
                offset(r = -2.0)
                    import("Tone_Dial_Pristine.dxf", layer = "SHELL");
            }
        // Screw pilot holes in the 4 corner tabs (depth 8mm)
        translate([-48.44,  45.86, 6.0]) cylinder(h = 8.5, d = 3.0, $fn = 24);
        translate([ 60.66,  46.13, 6.0]) cylinder(h = 8.5, d = 3.0, $fn = 24);
        translate([-49.73, -47.31, 6.0]) cylinder(h = 8.5, d = 3.0, $fn = 24);
        translate([ 70.85, -52.94, 6.0]) cylinder(h = 8.5, d = 3.0, $fn = 24);
    }
}

// Default preview:
top_faceplate();
// base_tray();
