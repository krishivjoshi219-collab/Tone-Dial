import trimesh
import numpy as np
from PIL import Image, ImageDraw
import os
import math
import time

t0 = time.time()
top = trimesh.load('Top_Faceplate.stl')
tray = trimesh.load('Base_Tray.stl')
knob = trimesh.load('Tone_Dial_Knob.stl')

theta = math.radians(12.0)
Rx_wedge = np.array([
    [1, 0, 0],
    [0, math.cos(-theta), -math.sin(-theta)],
    [0, math.sin(-theta), math.cos(-theta)]
])

# Seated top and knob on 12 deg tray rim
top_v = (Rx_wedge @ top.vertices.T).T
top_v[:, 2] += 23.45

knob_v = knob.vertices.copy()
knob_v[:, 0] += 55.47
knob_v[:, 1] += 14.37
knob_v[:, 2] += 6.0
knob_v = (Rx_wedge @ knob_v.T).T
knob_v[:, 2] += 23.45

lift_dir = np.array([0.0, -math.sin(theta), math.cos(theta)])

top_norm = (Rx_wedge @ top.face_normals.T).T
knob_norm = (Rx_wedge @ knob.face_normals.T).T

def render_scene(top_verts, top_normals, tray_mesh, knob_verts, knob_normals, out_path, yaw_deg=35, pitch_deg=30, img_size=(1024, 1024)):
    yaw = np.radians(yaw_deg)
    pitch = np.radians(pitch_deg)
    Ry = np.array([
        [np.cos(yaw), 0, np.sin(yaw)],
        [0, 1, 0],
        [-np.sin(yaw), 0, np.cos(yaw)]
    ])
    Rx_cam = np.array([
        [1, 0, 0],
        [0, np.cos(pitch), -np.sin(pitch)],
        [0, np.sin(pitch), np.cos(pitch)]
    ])
    R = Rx_cam @ Ry

    all_v = np.vstack([tray_mesh.vertices, top_verts, knob_verts])
    r_all = (R @ all_v.T).T
    min_xy = r_all[:, :2].min(axis=0)
    max_xy = r_all[:, :2].max(axis=0)
    center = (min_xy + max_xy) / 2
    scale = 0.80 * min(img_size) / max(max_xy - min_xy)

    im = Image.new('RGB', img_size, (245, 247, 250))
    draw = ImageDraw.Draw(im)

    key_light = np.array([0.45, -0.65, 0.60]); key_light /= np.linalg.norm(key_light)
    fill_light = np.array([-0.50, 0.30, 0.40]); fill_light /= np.linalg.norm(fill_light)

    def draw_part(v, f, norm, base_rgb):
        if len(v) == 0: return
        r_v = (R @ v.T).T
        r_n = (R @ norm.T).T
        vis = r_n[:, 2] >= -0.05
        f_vis = f[vis]
        n_vis = norm[vis]

        px_x = img_size[0] / 2 + (r_v[:, 0] - center[0]) * scale
        px_y = img_size[1] / 2 - (r_v[:, 1] - center[1]) * scale
        depth = r_v[:, 2]

        f_z = np.mean(v[f_vis, 2], axis=1)
        face_depths = np.mean(depth[f_vis], axis=1) + f_z * 0.15
        order = np.argsort(face_depths)

        dot_key = np.maximum(0.0, np.dot(n_vis, key_light))
        dot_fill = np.maximum(0.0, np.dot(n_vis, fill_light))
        shade = 0.22 + 0.65 * dot_key + 0.20 * dot_fill

        r = np.clip(base_rgb[0] * shade + 35 * dot_key, 0, 255).astype(np.uint8)
        g = np.clip(base_rgb[1] * shade + 35 * dot_key, 0, 255).astype(np.uint8)
        b = np.clip(base_rgb[2] * shade + 35 * dot_key, 0, 255).astype(np.uint8)

        pts_x = px_x[f_vis]
        pts_y = px_y[f_vis]

        for i in order:
            poly = [
                (pts_x[i, 0], pts_y[i, 0]),
                (pts_x[i, 1], pts_y[i, 1]),
                (pts_x[i, 2], pts_y[i, 2])
            ]
            draw.polygon(poly, fill=(r[i], g[i], b[i]))

    draw_part(tray_mesh.vertices, tray_mesh.faces, tray_mesh.face_normals, (68, 75, 88))
    draw_part(top_verts, top.faces, top_normals, (35, 175, 205))
    draw_part(knob_verts, knob.faces, knob_normals, (225, 185, 50))

    im.save(out_path)
    print(f"Saved: {out_path}")

art_dir = "/home/k/.gemini/antigravity-cli/brain/0dba677b-ced7-41cc-b0f7-402472b64599"

# 1. Assembled Isometric View
render_scene(top_v, top_norm, tray, knob_v, knob_norm, os.path.join(art_dir, "render_iso.png"), yaw_deg=38, pitch_deg=28)

# 2. 12° Wedge Side Profile View
render_scene(top_v, top_norm, tray, knob_v, knob_norm, os.path.join(art_dir, "render_side.png"), yaw_deg=90, pitch_deg=6)

# 3. Top-Down Orthographic View
render_scene(top_v, top_norm, tray, knob_v, knob_norm, os.path.join(art_dir, "render_top.png"), yaw_deg=0, pitch_deg=78)

# 4. Front View showing USB-C and Power Switch Cutouts
render_scene(top_v, top_norm, tray, knob_v, knob_norm, os.path.join(art_dir, "render_ports.png"), yaw_deg=0, pitch_deg=18)

# 5. Exploded View
top_v_exp = top_v + lift_dir * 45.0
knob_v_exp = knob_v + lift_dir * 80.0
render_scene(top_v_exp, top_norm, tray, knob_v_exp, knob_norm, os.path.join(art_dir, "render_exploded.png"), yaw_deg=38, pitch_deg=28)

# 6. Side by Side preview
im_top = Image.open(os.path.join(art_dir, "render_top.png"))
im_iso = Image.open(os.path.join(art_dir, "render_iso.png"))
w, h = im_top.size
sbs = Image.new('RGB', (w * 2, h))
sbs.paste(im_iso, (0, 0))
sbs.paste(im_top, (w, 0))
sbs.save(os.path.join(art_dir, "render_side_by_side.png"))

print(f"All renders generated in {time.time() - t0:.2f}s")
